# -*- coding: utf-8 -*-
# Jediný zdroj pravdy pro verzi / build agenta a instalátoru.
# Měňte zde před každým release; build_installer.py a UI z toho čtou.

BUILD_VERSION = "46"
