Logo aplikace DokuCheck pro desktop agenta
==========================================

Složka obsahuje:
- logo.png  … logo v sidebaru a záložka okna (pokud chybí .ico)
- logo.ico  … ikona okna na Windows (doporučeno: 32×32 nebo 48×48 px)

Jak přidat vlastní logo:
1. Nahraďte logo.png obrázkem v poměru cca 4:1 (šířka : výška), např. 280×70 px.
2. Pro ikonu v hlavičce okna a na taskbaru přidejte logo.ico (můžete vyexportovat z PNG např. na convertio.co nebo pomocí Pillow v Pythonu).

Barvy identity DokuCheck: tmavě modrá (#1e5a8a), zelená (#22c55e).
