Složka assets pro landing (workflow, obrázky).

workflow_schema.svg – schéma workflow na landingu (sekce „Automatizace kontroly“).
Můžete nahradit vlastním SVG. V kódu SVG opravte případné překlepy:
  opakoote → opakované
  Manžeská → Manažerská
