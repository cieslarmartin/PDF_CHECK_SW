================================================================================
  ZÁLOHA PŘED ÚPRAVOU FILTRŮ PDF (31.1.2026)
================================================================================

Soubor: pdf_dokucheck_pro_v41_with_api_20250131.py

Toto je záloha PŘED úpravami:
  - PDF/A-3: zeleně jen A-3, červeně A-2 / A-1 / NE (s vypsáním verze)
  - Podpis: zeleně autorizovaná osoba (ČKAIT), červeně podpis ne autor. / žádný
  - Razítko: VČR (zeleně), LOK a bez razítka (červeně), přejmenování TSA → VČR

JAK VRÁTIT PŮVODNÍ VERZI:
  1. Zkopírujte tento soubor zpět:
     copy pdf_dokucheck_pro_v41_with_api_20250131.py ..\pdf_dokucheck_pro_v41_with_api.py
  2. Nebo v PowerShellu:
     Copy-Item .\pdf_dokucheck_pro_v41_with_api_20250131.py -Destination ..\pdf_dokucheck_pro_v41_with_api.py

================================================================================
