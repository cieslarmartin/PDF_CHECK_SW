# version.py
# Jediné místo pro číslo buildu webové aplikace.
# Při každé nasazené změně zvyš číslo – zobrazí se na landingu a v Admin dashboardu.
#
# Historie (příklady):
# 45 – Odkaz z Agenta: přihlášení a přesměrování rovnou na /app (kontroly), ne na landing
# 44 – Redesign ceníku (Basic/Pro karty), číslování buildu
# 43 – ...
# 42 – Admin bez grafů, log Online Dema, velká tlačítka

WEB_BUILD = 45
