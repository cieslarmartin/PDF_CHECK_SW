# database.py
# SQLite databáze pro PDF DokuCheck Web Backend
# Build 41 | © 2025 Ing. Martin Cieślar
# NOVÉ: Licenční systém, device binding, feature flags, Admin systém

import sqlite3
import json
from datetime import datetime, timedelta
import os
import uuid

# Absolute DB path (required on PythonAnywhere/WSGI – CWD may not be app dir)
basedir = os.path.abspath(os.path.dirname(__file__))
db_path = os.path.join(basedir, 'pdfcheck_results.db')
_default_db_path = db_path  # used by Database.__init__ when no path is passed

import hashlib
import secrets

# Import licenční konfigurace
try:
    from license_config import LicenseTier, tier_from_string, tier_to_string
except ImportError:
    # Fallback pokud není k dispozici
    class LicenseTier:
        FREE = 0
        BASIC = 1
        PRO = 2
        ENTERPRISE = 3
    def tier_from_string(s): return LicenseTier.FREE
    def tier_to_string(t): return "Free"


class Database:
    """Správa SQLite databáze pro výsledky kontrol"""

    def __init__(self, db_path=None):
        self.db_path = db_path if db_path is not None else _default_db_path  # absolute path on PA
        self.init_database()

    def get_connection(self):
        """Vytvoří připojení k databázi"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # Vrací dict místo tuple
        return conn

    def init_database(self):
        """Inicializuje databázové tabulky"""
        conn = self.get_connection()
        cursor = conn.cursor()

        # Tabulka API klíčů - ROZŠÍŘENÁ o licenční údaje
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                api_key TEXT UNIQUE NOT NULL,
                user_name TEXT,
                email TEXT,
                license_tier INTEGER DEFAULT 0,
                license_expires TIMESTAMP,
                max_devices INTEGER DEFAULT 1,
                rate_limit_hour INTEGER DEFAULT 3,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            )
        ''')

        # NOVÁ: Tabulka aktivací zařízení (device binding)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS device_activations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                api_key TEXT NOT NULL,
                hwid TEXT NOT NULL,
                device_name TEXT,
                os_info TEXT,
                activated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT 1,
                FOREIGN KEY (api_key) REFERENCES api_keys(api_key),
                UNIQUE(api_key, hwid)
            )
        ''')

        # NOVÁ: Tabulka rate limitingu pro free tier
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS rate_limits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                identifier TEXT NOT NULL,
                identifier_type TEXT DEFAULT 'ip',
                action_type TEXT DEFAULT 'check',
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # NOVÁ: Tabulka dávek (batches)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS batches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch_id TEXT UNIQUE NOT NULL,
                api_key TEXT NOT NULL,
                batch_name TEXT,
                source_folder TEXT,
                total_files INTEGER DEFAULT 0,
                pdf_a3_count INTEGER DEFAULT 0,
                signed_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (api_key) REFERENCES api_keys(api_key)
            )
        ''')

        # Tabulka výsledků kontrol - UPRAVENÁ s batch_id a folder strukturou
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS check_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                api_key TEXT NOT NULL,
                batch_id TEXT,
                file_name TEXT NOT NULL,
                file_path TEXT,
                folder_path TEXT,
                file_hash TEXT,
                file_size INTEGER,
                processed_at TIMESTAMP,
                is_pdf_a3 BOOLEAN,
                pdf_version TEXT,
                signature_count INTEGER,
                has_errors BOOLEAN,
                results_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (api_key) REFERENCES api_keys(api_key),
                FOREIGN KEY (batch_id) REFERENCES batches(batch_id)
            )
        ''')

        # Indexy pro rychlejší vyhledávání
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_api_key ON check_results(api_key)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_batch_id ON check_results(batch_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_file_hash ON check_results(file_hash)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_folder_path ON check_results(folder_path)')

        # Indexy pro licenční systém
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_device_api_key ON device_activations(api_key)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_device_hwid ON device_activations(hwid)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_rate_identifier ON rate_limits(identifier)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_rate_timestamp ON rate_limits(timestamp)')

        # NOVÁ: Tabulka admin uživatelů
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS admin_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT DEFAULT 'USER',
                display_name TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_admin_email ON admin_users(email)')

        # Migrace: přidej nové sloupce pokud neexistují (pro existující databáze)
        self._migrate_schema(cursor)

        conn.commit()
        conn.close()

    def _migrate_schema(self, cursor):
        """Migruje schéma pro existující databáze"""
        # Získej existující sloupce v api_keys
        cursor.execute("PRAGMA table_info(api_keys)")
        existing_columns = {row[1] for row in cursor.fetchall()}

        # Přidej chybějící sloupce
        new_columns = {
            'email': 'TEXT',
            'license_tier': 'INTEGER DEFAULT 0',
            'license_expires': 'TIMESTAMP',
            'max_devices': 'INTEGER DEFAULT 1',
            'rate_limit_hour': 'INTEGER DEFAULT 3',
            'password_hash': 'TEXT',  # heslo pro přihlášení uživatele v agentovi (e-mail + heslo)
        }

        for col_name, col_type in new_columns.items():
            if col_name not in existing_columns:
                try:
                    cursor.execute(f'ALTER TABLE api_keys ADD COLUMN {col_name} {col_type}')
                except sqlite3.OperationalError:
                    pass  # Sloupec už existuje

    def create_api_key(self, api_key, user_name=None):
        """Vytvoří nový API klíč"""
        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute('''
                INSERT INTO api_keys (api_key, user_name)
                VALUES (?, ?)
            ''', (api_key, user_name))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False  # Klíč už existuje
        finally:
            conn.close()

    def verify_api_key(self, api_key):
        """Ověří platnost API klíče"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, is_active FROM api_keys
            WHERE api_key = ?
        ''', (api_key,))

        result = cursor.fetchone()
        conn.close()

        if result and result['is_active']:
            return True
        return False

    # =========================================================================
    # BATCH OPERACE (NOVÉ v40)
    # =========================================================================

    def create_batch(self, api_key, batch_name=None, source_folder=None):
        """Vytvoří novou dávku a vrátí batch_id"""
        conn = self.get_connection()
        cursor = conn.cursor()

        batch_id = f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"

        try:
            cursor.execute('''
                INSERT INTO batches (batch_id, api_key, batch_name, source_folder)
                VALUES (?, ?, ?, ?)
            ''', (batch_id, api_key, batch_name, source_folder))
            conn.commit()
            return batch_id
        except Exception as e:
            print(f"Chyba při vytváření batch: {e}")
            return None
        finally:
            conn.close()

    def update_batch_stats(self, batch_id):
        """Aktualizuje statistiky dávky"""
        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            # Spočítej statistiky
            cursor.execute('''
                SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN is_pdf_a3 = 1 THEN 1 ELSE 0 END) as pdf_a3,
                    SUM(CASE WHEN signature_count > 0 THEN 1 ELSE 0 END) as signed
                FROM check_results
                WHERE batch_id = ?
            ''', (batch_id,))
            stats = cursor.fetchone()

            cursor.execute('''
                UPDATE batches
                SET total_files = ?, pdf_a3_count = ?, signed_count = ?
                WHERE batch_id = ?
            ''', (stats['total'], stats['pdf_a3'], stats['signed'], batch_id))

            conn.commit()
        finally:
            conn.close()

    def get_batches(self, api_key=None, limit=50):
        """Vrátí seznam dávek"""
        conn = self.get_connection()
        cursor = conn.cursor()

        if api_key:
            cursor.execute('''
                SELECT * FROM batches
                WHERE api_key = ?
                ORDER BY created_at DESC
                LIMIT ?
            ''', (api_key, limit))
        else:
            cursor.execute('''
                SELECT * FROM batches
                ORDER BY created_at DESC
                LIMIT ?
            ''', (limit,))

        results = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return results

    def get_batch_api_key(self, batch_id):
        """Vrátí api_key vlastníka dávky (pro ověření přístupu)."""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT api_key FROM batches WHERE batch_id = ?', (batch_id,))
        row = cursor.fetchone()
        conn.close()
        return row['api_key'] if row else None

    def get_batch_results(self, batch_id):
        """Vrátí všechny výsledky pro danou dávku"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT * FROM check_results
            WHERE batch_id = ?
            ORDER BY folder_path, file_name
        ''', (batch_id,))

        results = [dict(row) for row in cursor.fetchall()]
        conn.close()

        # Parsuj JSON
        for result in results:
            if result.get('results_json'):
                result['parsed_results'] = json.loads(result['results_json'])

        return results

    def delete_batch(self, batch_id):
        """Smaže dávku a všechny její výsledky"""
        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute('DELETE FROM check_results WHERE batch_id = ?', (batch_id,))
            cursor.execute('DELETE FROM batches WHERE batch_id = ?', (batch_id,))
            conn.commit()
            return True
        except Exception as e:
            print(f"Chyba při mazání batch: {e}")
            return False
        finally:
            conn.close()

    def delete_all_results(self):
        """Smaže VŠECHNY výsledky a batche (pouze admin)."""
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('SELECT COUNT(*) FROM check_results')
            count = cursor.fetchone()[0]
            cursor.execute('DELETE FROM check_results')
            cursor.execute('DELETE FROM batches')
            conn.commit()
            return count
        except Exception as e:
            print(f"Chyba při mazání všech dat: {e}")
            return 0
        finally:
            conn.close()

    def delete_all_results_for_api_key(self, api_key):
        """Smaže pouze výsledky a batche daného uživatele (pro web – „Vymazat vše“)."""
        if not api_key:
            return 0
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('SELECT COUNT(*) FROM check_results WHERE api_key = ?', (api_key,))
            count = cursor.fetchone()[0]
            cursor.execute('DELETE FROM check_results WHERE api_key = ?', (api_key,))
            cursor.execute('DELETE FROM batches WHERE api_key = ?', (api_key,))
            conn.commit()
            return count
        except Exception as e:
            print(f"Chyba při mazání dat uživatele: {e}")
            return 0
        finally:
            conn.close()

    # =========================================================================
    # VÝSLEDKY S BATCH PODPOROU
    # =========================================================================

    def save_result(self, api_key, result_data, batch_id=None):
        """Uloží výsledek kontroly do databáze"""
        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            # Extrahuj data z result_data
            file_name = result_data.get('file_name')
            file_path = result_data.get('relative_path') or result_data.get('file_path') or file_name
            folder_path = result_data.get('folder') or os.path.dirname(file_path) or '.'
            file_hash = result_data.get('file_hash')
            file_size = result_data.get('file_size')
            processed_at = result_data.get('processed_at')

            results = result_data.get('results', {})
            pdf_format = results.get('pdf_format', {})
            signatures = results.get('signatures', [])

            is_pdf_a3 = pdf_format.get('is_pdf_a3', False)
            pdf_version = pdf_format.get('exact_version', 'Unknown')
            signature_count = len(signatures)
            has_errors = not result_data.get('success', True)

            # Ulož jako JSON string
            results_json = json.dumps(result_data, ensure_ascii=False)

            cursor.execute('''
                INSERT INTO check_results (
                    api_key, batch_id, file_name, file_path, folder_path, file_hash, file_size, processed_at,
                    is_pdf_a3, pdf_version, signature_count, has_errors, results_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                api_key, batch_id, file_name, file_path, folder_path, file_hash, file_size, processed_at,
                is_pdf_a3, pdf_version, signature_count, has_errors, results_json
            ))

            conn.commit()
            return True, cursor.lastrowid

        except Exception as e:
            return False, str(e)
        finally:
            conn.close()

    def get_results_by_api_key(self, api_key, limit=100, offset=0):
        """Vrátí výsledky pro daný API klíč"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT * FROM check_results
            WHERE api_key = ?
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        ''', (api_key, limit, offset))

        results = [dict(row) for row in cursor.fetchall()]
        conn.close()

        # Parsuj JSON zpět
        for result in results:
            if result.get('results_json'):
                result['parsed_results'] = json.loads(result['results_json'])

        return results

    def get_statistics(self, api_key):
        """Vrátí statistiky pro API klíč"""
        conn = self.get_connection()
        cursor = conn.cursor()

        # Celkový počet kontrol
        cursor.execute('''
            SELECT COUNT(*) as total FROM check_results
            WHERE api_key = ?
        ''', (api_key,))
        total = cursor.fetchone()['total']

        # PDF/A-3 kontroly
        cursor.execute('''
            SELECT COUNT(*) as count FROM check_results
            WHERE api_key = ? AND is_pdf_a3 = 1
        ''', (api_key,))
        pdf_a3_count = cursor.fetchone()['count']

        # Kontroly s chybami
        cursor.execute('''
            SELECT COUNT(*) as count FROM check_results
            WHERE api_key = ? AND has_errors = 1
        ''', (api_key,))
        errors_count = cursor.fetchone()['count']

        # Kontroly s podpisy
        cursor.execute('''
            SELECT COUNT(*) as count FROM check_results
            WHERE api_key = ? AND signature_count > 0
        ''', (api_key,))
        signed_count = cursor.fetchone()['count']

        conn.close()

        return {
            'total_checks': total,
            'pdf_a3_count': pdf_a3_count,
            'pdf_a3_percentage': (pdf_a3_count / total * 100) if total > 0 else 0,
            'errors_count': errors_count,
            'success_count': total - errors_count,
            'signed_count': signed_count
        }

    def get_all_api_keys(self):
        """Vrátí všechny API klíče (pro admin)"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('SELECT * FROM api_keys ORDER BY created_at DESC')
        keys = [dict(row) for row in cursor.fetchall()]
        conn.close()

        return keys

    # =========================================================================
    # AGENT RESULTS (pro webové rozhraní)
    # =========================================================================

    def get_agent_results_grouped(self, limit=50, api_key=None):
        """
        Vrátí výsledky seskupené podle batchů pro webové rozhraní.
        Pokud je api_key zadán, vrací jen batche tohoto uživatele (pro přihlášené na webu).
        """
        conn = self.get_connection()
        cursor = conn.cursor()

        # Získej batche (volitelně jen pro daného uživatele)
        if api_key:
            cursor.execute('''
                SELECT * FROM batches
                WHERE api_key = ?
                ORDER BY created_at DESC
                LIMIT ?
            ''', (api_key, limit))
        else:
            cursor.execute('''
                SELECT * FROM batches
                ORDER BY created_at DESC
                LIMIT ?
            ''', (limit,))
        batches = [dict(row) for row in cursor.fetchall()]

        # Pro každý batch získej výsledky
        for batch in batches:
            cursor.execute('''
                SELECT * FROM check_results
                WHERE batch_id = ?
                ORDER BY folder_path, file_name
            ''', (batch['batch_id'],))
            results = [dict(row) for row in cursor.fetchall()]

            # Parsuj JSON
            for result in results:
                if result.get('results_json'):
                    result['parsed_results'] = json.loads(result['results_json'])

            batch['results'] = results

            # Vytvoř stromovou strukturu složek
            batch['folder_tree'] = self._build_folder_tree(results)

        conn.close()

        # Také získej výsledky bez batch_id (staré záznamy) – při api_key jen tohoto uživatele
        conn2 = self.get_connection()
        cursor2 = conn2.cursor()
        if api_key:
            cursor2.execute('''
                SELECT * FROM check_results
                WHERE batch_id IS NULL AND api_key = ?
                ORDER BY created_at DESC
                LIMIT 500
            ''', (api_key,))
        else:
            cursor2.execute('''
                SELECT * FROM check_results
                WHERE batch_id IS NULL
                ORDER BY created_at DESC
                LIMIT 500
            ''')
        legacy_results = [dict(row) for row in cursor2.fetchall()]
        conn2.close()

        for result in legacy_results:
            if result.get('results_json'):
                result['parsed_results'] = json.loads(result['results_json'])

        # Seskup legacy výsledky podle data
        if legacy_results:
            legacy_grouped = {}
            for r in legacy_results:
                date = r['created_at'].split(' ')[0] if r.get('created_at') else 'Neznámé'
                if date not in legacy_grouped:
                    legacy_grouped[date] = []
                legacy_grouped[date].append(r)

            # Přidej jako pseudo-batche
            for date, results in legacy_grouped.items():
                batches.append({
                    'batch_id': f'legacy_{date}',
                    'batch_name': f'Import - {date}',
                    'source_folder': None,
                    'total_files': len(results),
                    'created_at': date,
                    'results': results,
                    'folder_tree': self._build_folder_tree(results),
                    'is_legacy': True
                })

        return batches

    def _build_folder_tree(self, results):
        """Vytvoří stromovou strukturu složek z výsledků"""
        tree = {}

        for result in results:
            folder = result.get('folder_path') or '.'

            if folder not in tree:
                tree[folder] = []

            tree[folder].append({
                'file_name': result.get('file_name'),
                'file_path': result.get('file_path'),
                'is_pdf_a3': result.get('is_pdf_a3'),
                'signature_count': result.get('signature_count'),
                'parsed_results': result.get('parsed_results')
            })

        return tree

    # =========================================================================
    # LICENČNÍ SYSTÉM (NOVÉ v41)
    # =========================================================================

    def create_api_key_with_license(self, api_key, user_name=None, email=None,
                                     license_tier=0, license_days=None, password=None):
        """Vytvoří nový API klíč s licenčními údaji. password = heslo pro přihlášení uživatele (e-mail+heslo) v agentovi."""
        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            license_expires = None
            if license_days and license_days > 0:
                license_expires = (datetime.now() + timedelta(days=license_days)).isoformat()

            try:
                from license_config import get_tier_limits, LicenseTier
                limits = get_tier_limits(LicenseTier(license_tier))
                max_devices = limits.get('max_devices', 1)
                rate_limit = limits.get('rate_limit_per_hour', 3)
            except ImportError:
                max_devices = 1
                rate_limit = 3

            password_hash = self._hash_password(password) if password and str(password).strip() else None

            cursor.execute('''
                INSERT INTO api_keys (api_key, user_name, email, license_tier,
                                     license_expires, max_devices, rate_limit_hour, password_hash)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (api_key, user_name, email, license_tier, license_expires,
                  max_devices, rate_limit, password_hash))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()

    def get_license_by_email(self, email):
        """Vrátí záznam licence podle e-mailu (pro přihlášení uživatele)."""
        if not email or not str(email).strip():
            return None
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, api_key, user_name, email, license_tier, license_expires,
                   max_devices, rate_limit_hour, created_at, is_active, password_hash
            FROM api_keys
            WHERE LOWER(TRIM(email)) = LOWER(TRIM(?)) AND is_active = 1
        ''', (email.strip(),))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    def verify_license_password(self, email, password):
        """
        Ověří přihlášení uživatele e-mailem a heslem.
        Vrátí (True, license_info_dict) nebo (False, error_message).
        license_info_dict obsahuje api_key, user_name, email, tier_name (bez password_hash).
        """
        row = self.get_license_by_email(email)
        if not row:
            return False, "Neplatný e-mail nebo heslo"
        if not row.get('is_active'):
            return False, "Účet je deaktivován"
        license_info = self.get_user_license(row['api_key'])
        if license_info and license_info.get('is_expired'):
            return False, "Licence vypršela"
        ph = row.get('password_hash')
        if not ph:
            return False, "Pro tento účet není nastaveno heslo – použijte licenční klíč v agentovi"
        if not self._verify_password(password, ph):
            return False, "Neplatný e-mail nebo heslo"
        # Vrátit údaje bez password_hash
        out = {
            'api_key': row['api_key'],
            'user_name': row.get('user_name'),
            'email': row.get('email'),
            'license_tier': row.get('license_tier', 0),
            'tier_name': tier_to_string(LicenseTier(row.get('license_tier', 0))),
        }
        return True, out

    def get_user_license(self, api_key):
        """Vrátí kompletní licenční informace pro API klíč"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, api_key, user_name, email, license_tier, license_expires,
                   max_devices, rate_limit_hour, created_at, is_active
            FROM api_keys
            WHERE api_key = ?
        ''', (api_key,))

        row = cursor.fetchone()
        conn.close()

        if not row:
            return None

        result = dict(row)

        # Přidej tier name
        result['tier_name'] = tier_to_string(LicenseTier(result['license_tier']))

        # Zkontroluj expiraci
        if result['license_expires']:
            try:
                exp_date = datetime.fromisoformat(result['license_expires'])
                result['is_expired'] = exp_date < datetime.now()
                result['days_remaining'] = (exp_date - datetime.now()).days
            except:
                result['is_expired'] = False
                result['days_remaining'] = -1
        else:
            result['is_expired'] = False
            result['days_remaining'] = -1  # Neomezeno

        # Spočítej aktivní zařízení
        result['active_devices'] = self.count_active_devices(api_key)

        return result

    def update_license_tier(self, api_key, new_tier, license_days=None):
        """Aktualizuje licenční tier pro uživatele"""
        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            # Získej limity pro nový tier
            try:
                from license_config import get_tier_limits, LicenseTier
                limits = get_tier_limits(LicenseTier(new_tier))
                max_devices = limits.get('max_devices', 1)
                rate_limit = limits.get('rate_limit_per_hour', 3)
            except ImportError:
                max_devices = 1
                rate_limit = 3

            # Vypočítej novou expiraci
            license_expires = None
            if license_days and license_days > 0:
                license_expires = (datetime.now() + timedelta(days=license_days)).isoformat()

            cursor.execute('''
                UPDATE api_keys
                SET license_tier = ?, license_expires = ?,
                    max_devices = ?, rate_limit_hour = ?
                WHERE api_key = ?
            ''', (new_tier, license_expires, max_devices, rate_limit, api_key))

            conn.commit()
            return cursor.rowcount > 0
        finally:
            conn.close()

    # =========================================================================
    # DEVICE ACTIVATION (Device Binding)
    # =========================================================================

    def register_device(self, api_key, hwid, device_name=None, os_info=None):
        """
        Registruje nové zařízení pro API klíč

        Returns:
            tuple: (success: bool, message: str)
        """
        # Nejprve zkontroluj licenci
        license_info = self.get_user_license(api_key)
        if not license_info:
            return False, "Neplatný API klíč"

        if not license_info['is_active']:
            return False, "Účet je deaktivován"

        if license_info['is_expired']:
            return False, "Licence vypršela"

        # Zkontroluj limit zařízení
        max_devices = license_info.get('max_devices', 1)
        if max_devices != -1:  # -1 = neomezeno
            active_count = self.count_active_devices(api_key)

            # Zkontroluj jestli toto zařízení už není registrováno
            existing = self.get_device_activation(api_key, hwid)
            if existing:
                # Zařízení už existuje - aktualizuj last_seen
                self.update_device_last_seen(api_key, hwid)
                return True, "Zařízení již registrováno"

            if active_count >= max_devices:
                return False, f"Dosažen limit {max_devices} zařízení"

        # Registruj zařízení
        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute('''
                INSERT INTO device_activations (api_key, hwid, device_name, os_info)
                VALUES (?, ?, ?, ?)
            ''', (api_key, hwid, device_name, os_info))
            conn.commit()
            return True, "Zařízení úspěšně registrováno"
        except sqlite3.IntegrityError:
            # Zařízení už existuje
            self.update_device_last_seen(api_key, hwid)
            return True, "Zařízení již registrováno"
        finally:
            conn.close()

    def validate_device(self, api_key, hwid):
        """
        Validuje zařízení pro použití s API klíčem

        Returns:
            tuple: (valid: bool, license_info: dict or error_message: str)
        """
        # Získej licenci
        license_info = self.get_user_license(api_key)
        if not license_info:
            return False, "Neplatný API klíč"

        if not license_info['is_active']:
            return False, "Účet je deaktivován"

        if license_info['is_expired']:
            return False, "Licence vypršela"

        # Zkontroluj zařízení
        device = self.get_device_activation(api_key, hwid)
        if not device:
            # Zkus registrovat automaticky
            success, msg = self.register_device(api_key, hwid)
            if not success:
                return False, msg
            device = self.get_device_activation(api_key, hwid)

        if device and not device['is_active']:
            return False, "Zařízení je deaktivováno"

        # Aktualizuj last_seen
        self.update_device_last_seen(api_key, hwid)

        # Přidej features a limits do výsledku
        try:
            from license_config import get_tier_features, get_tier_limits, LicenseTier
            tier = LicenseTier(license_info['license_tier'])
            license_info['features'] = get_tier_features(tier)
            license_info['limits'] = get_tier_limits(tier)
        except ImportError:
            license_info['features'] = []
            license_info['limits'] = {}

        return True, license_info

    def get_device_activation(self, api_key, hwid):
        """Vrátí informace o aktivaci zařízení"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT * FROM device_activations
            WHERE api_key = ? AND hwid = ?
        ''', (api_key, hwid))

        row = cursor.fetchone()
        conn.close()

        return dict(row) if row else None

    def get_active_devices(self, api_key):
        """Vrátí seznam aktivních zařízení pro API klíč"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT * FROM device_activations
            WHERE api_key = ? AND is_active = 1
            ORDER BY last_seen DESC
        ''', (api_key,))

        devices = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return devices

    def count_active_devices(self, api_key):
        """Spočítá aktivní zařízení pro API klíč"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT COUNT(*) as count FROM device_activations
            WHERE api_key = ? AND is_active = 1
        ''', (api_key,))

        result = cursor.fetchone()['count']
        conn.close()
        return result

    def update_device_last_seen(self, api_key, hwid):
        """Aktualizuje čas posledního použití zařízení"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            UPDATE device_activations
            SET last_seen = CURRENT_TIMESTAMP
            WHERE api_key = ? AND hwid = ?
        ''', (api_key, hwid))

        conn.commit()
        conn.close()

    def deactivate_device(self, api_key, hwid):
        """Deaktivuje zařízení"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            UPDATE device_activations
            SET is_active = 0
            WHERE api_key = ? AND hwid = ?
        ''', (api_key, hwid))

        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return success

    def remove_device(self, api_key, hwid):
        """Odstraní zařízení úplně"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            DELETE FROM device_activations
            WHERE api_key = ? AND hwid = ?
        ''', (api_key, hwid))

        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return success

    # =========================================================================
    # RATE LIMITING
    # =========================================================================

    def check_rate_limit(self, identifier, identifier_type='ip', action_type='check',
                         max_per_hour=3):
        """
        Zkontroluje a případně zaznamená akci pro rate limiting

        Args:
            identifier: IP adresa nebo jiný identifikátor
            identifier_type: Typ identifikátoru ('ip', 'session', 'fingerprint')
            action_type: Typ akce ('check', 'upload', 'export')
            max_per_hour: Maximální počet akcí za hodinu

        Returns:
            tuple: (allowed: bool, remaining: int, reset_seconds: int)
        """
        conn = self.get_connection()
        cursor = conn.cursor()

        # Spočítej akce za poslední hodinu
        one_hour_ago = (datetime.now() - timedelta(hours=1)).isoformat()

        cursor.execute('''
            SELECT COUNT(*) as count FROM rate_limits
            WHERE identifier = ? AND identifier_type = ? AND action_type = ?
            AND timestamp > ?
        ''', (identifier, identifier_type, action_type, one_hour_ago))

        count = cursor.fetchone()['count']

        # Zjisti čas první akce v okně (pro reset time)
        cursor.execute('''
            SELECT MIN(timestamp) as first_action FROM rate_limits
            WHERE identifier = ? AND identifier_type = ? AND action_type = ?
            AND timestamp > ?
        ''', (identifier, identifier_type, action_type, one_hour_ago))

        first_action = cursor.fetchone()['first_action']

        conn.close()

        # Vypočítej zbývající akce a reset time
        remaining = max(0, max_per_hour - count)

        if first_action:
            try:
                first_time = datetime.fromisoformat(first_action)
                reset_time = first_time + timedelta(hours=1)
                reset_seconds = int((reset_time - datetime.now()).total_seconds())
                reset_seconds = max(0, reset_seconds)
            except:
                reset_seconds = 3600
        else:
            reset_seconds = 3600

        return count < max_per_hour, remaining, reset_seconds

    def record_rate_limit_action(self, identifier, identifier_type='ip',
                                  action_type='check'):
        """Zaznamená akci pro rate limiting"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO rate_limits (identifier, identifier_type, action_type)
            VALUES (?, ?, ?)
        ''', (identifier, identifier_type, action_type))

        conn.commit()
        conn.close()

    def cleanup_rate_limits(self, hours_old=24):
        """Vyčistí staré záznamy rate limitingu"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cutoff = (datetime.now() - timedelta(hours=hours_old)).isoformat()

        cursor.execute('''
            DELETE FROM rate_limits
            WHERE timestamp < ?
        ''', (cutoff,))

        deleted = cursor.rowcount
        conn.commit()
        conn.close()
        return deleted

    # =========================================================================
    # ADMIN SYSTÉM (NOVÉ v41)
    # =========================================================================

    def _hash_password(self, password: str) -> str:
        """Vytvoří hash hesla s náhodnou solí"""
        salt = secrets.token_hex(16)
        password_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        ).hex()
        return f"{salt}${password_hash}"

    def _verify_password(self, password: str, password_hash: str) -> bool:
        """Ověří heslo proti hashi"""
        try:
            salt, stored_hash = password_hash.split('$')
            computed_hash = hashlib.pbkdf2_hmac(
                'sha256',
                password.encode('utf-8'),
                salt.encode('utf-8'),
                100000
            ).hex()
            return secrets.compare_digest(computed_hash, stored_hash)
        except (ValueError, AttributeError):
            return False

    def create_admin_user(self, email: str, password: str, role: str = 'USER',
                          display_name: str = None) -> tuple:
        """
        Vytvoří nového admin uživatele

        Args:
            email: Email uživatele (unikátní)
            password: Heslo v čitelné formě
            role: 'USER' nebo 'ADMIN'
            display_name: Zobrazované jméno

        Returns:
            tuple: (success: bool, message: str)
        """
        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            password_hash = self._hash_password(password)

            cursor.execute('''
                INSERT INTO admin_users (email, password_hash, role, display_name)
                VALUES (?, ?, ?, ?)
            ''', (email, password_hash, role.upper(), display_name or email.split('@')[0]))

            conn.commit()
            return True, "Uživatel vytvořen"
        except sqlite3.IntegrityError:
            return False, "Email už existuje"
        except Exception as e:
            return False, str(e)
        finally:
            conn.close()

    def verify_admin_login(self, email: str, password: str) -> tuple:
        """
        Ověří přihlášení admin uživatele

        Returns:
            tuple: (success: bool, user_dict or error_message)
        """
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, email, password_hash, role, display_name, is_active
            FROM admin_users
            WHERE email = ?
        ''', (email,))

        row = cursor.fetchone()

        if not row:
            conn.close()
            return False, "Neplatný email nebo heslo"

        user = dict(row)

        if not user['is_active']:
            conn.close()
            return False, "Účet je deaktivován"

        if not self._verify_password(password, user['password_hash']):
            conn.close()
            return False, "Neplatný email nebo heslo"

        # Aktualizuj last_login
        cursor.execute('''
            UPDATE admin_users SET last_login = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (user['id'],))
        conn.commit()
        conn.close()

        # Odstraň hash z výsledku
        del user['password_hash']
        return True, user

    def get_admin_by_email(self, email: str) -> dict:
        """Vrátí admin uživatele podle emailu"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, email, role, display_name, created_at, last_login, is_active
            FROM admin_users
            WHERE email = ?
        ''', (email,))

        row = cursor.fetchone()
        conn.close()

        return dict(row) if row else None

    def get_admin_by_id(self, user_id: int) -> dict:
        """Vrátí admin uživatele podle ID"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, email, role, display_name, created_at, last_login, is_active
            FROM admin_users
            WHERE id = ?
        ''', (user_id,))

        row = cursor.fetchone()
        conn.close()

        return dict(row) if row else None

    def get_all_admin_users(self) -> list:
        """Vrátí všechny admin uživatele"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, email, role, display_name, created_at, last_login, is_active
            FROM admin_users
            ORDER BY created_at DESC
        ''')

        users = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return users

    def update_admin_user(self, user_id: int, **kwargs) -> bool:
        """Aktualizuje admin uživatele"""
        conn = self.get_connection()
        cursor = conn.cursor()

        allowed_fields = ['email', 'role', 'display_name', 'is_active']
        updates = []
        values = []

        for field, value in kwargs.items():
            if field in allowed_fields:
                updates.append(f"{field} = ?")
                values.append(value)
            elif field == 'password' and value:
                updates.append("password_hash = ?")
                values.append(self._hash_password(value))

        if not updates:
            conn.close()
            return False

        values.append(user_id)
        query = f"UPDATE admin_users SET {', '.join(updates)} WHERE id = ?"

        cursor.execute(query, values)
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return success

    def delete_admin_user(self, user_id: int) -> bool:
        """Smaže admin uživatele"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('DELETE FROM admin_users WHERE id = ?', (user_id,))
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return success

    def is_admin(self, email: str) -> bool:
        """Zkontroluje zda je uživatel admin"""
        user = self.get_admin_by_email(email)
        return user is not None and user.get('role') == 'ADMIN' and user.get('is_active')

    # =========================================================================
    # ADMIN: SPRÁVA LICENCÍ (rozšířené metody)
    # =========================================================================

    def admin_get_all_licenses(self) -> list:
        """Vrátí všechny licence s detailními informacemi pro admin dashboard"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT
                ak.id,
                ak.api_key,
                ak.user_name,
                ak.email,
                ak.license_tier,
                ak.license_expires,
                ak.max_devices,
                ak.rate_limit_hour,
                ak.created_at,
                ak.is_active,
                (SELECT COUNT(*) FROM device_activations da
                 WHERE da.api_key = ak.api_key AND da.is_active = 1) as active_devices,
                (SELECT COUNT(*) FROM check_results cr
                 WHERE cr.api_key = ak.api_key) as total_checks
            FROM api_keys ak
            ORDER BY ak.created_at DESC
        ''')

        licenses = []
        for row in cursor.fetchall():
            license_data = dict(row)
            license_data['tier_name'] = tier_to_string(LicenseTier(license_data['license_tier']))

            # Zkontroluj expiraci
            if license_data['license_expires']:
                try:
                    exp_date = datetime.fromisoformat(license_data['license_expires'])
                    license_data['is_expired'] = exp_date < datetime.now()
                    license_data['days_remaining'] = (exp_date - datetime.now()).days
                except:
                    license_data['is_expired'] = False
                    license_data['days_remaining'] = -1
            else:
                license_data['is_expired'] = False
                license_data['days_remaining'] = -1

            licenses.append(license_data)

        conn.close()
        return licenses

    def admin_reset_devices(self, api_key: str) -> int:
        """Resetuje všechna zařízení pro daný API klíč (admin funkce)"""
        conn = self.get_connection()
        cursor = conn.cursor()

        cursor.execute('''
            DELETE FROM device_activations
            WHERE api_key = ?
        ''', (api_key,))

        deleted = cursor.rowcount
        conn.commit()
        conn.close()
        return deleted

    def admin_delete_license(self, api_key: str) -> bool:
        """Smaže licenci a všechna související data (admin funkce)"""
        conn = self.get_connection()
        cursor = conn.cursor()

        try:
            # Smaž zařízení
            cursor.execute('DELETE FROM device_activations WHERE api_key = ?', (api_key,))
            # Smaž výsledky (volitelně - můžeme nechat)
            # cursor.execute('DELETE FROM check_results WHERE api_key = ?', (api_key,))
            # Smaž API klíč
            cursor.execute('DELETE FROM api_keys WHERE api_key = ?', (api_key,))

            conn.commit()
            return True
        except Exception as e:
            print(f"Error deleting license: {e}")
            return False
        finally:
            conn.close()

    def admin_set_license_password(self, api_key: str, new_password: str) -> bool:
        """Nastaví nebo změní heslo pro přihlášení uživatele v agentovi (e-mail + heslo)."""
        if not api_key or not str(api_key).strip():
            return False
        if not new_password or not str(new_password).strip():
            return False
        conn = self.get_connection()
        cursor = conn.cursor()
        password_hash = self._hash_password(new_password.strip())
        cursor.execute(
            'UPDATE api_keys SET password_hash = ? WHERE api_key = ?',
            (password_hash, api_key.strip())
        )
        success = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return success

    def admin_generate_license_key(self, user_name: str, email: str,
                                    tier: int, days: int = 365, password: str = None) -> str:
        """Vygeneruje nový licenční klíč (admin funkce). password = heslo pro přihlášení uživatele v agentovi (e-mail+heslo)."""
        prefix = ['sk_free_', 'sk_basic_', 'sk_pro_', 'sk_ent_'][min(tier, 3)]
        api_key = prefix + secrets.token_hex(16)

        success = self.create_api_key_with_license(
            api_key=api_key,
            user_name=user_name,
            email=email,
            license_tier=tier,
            license_days=days,
            password=password,
        )

        return api_key if success else None


# Helper funkce pro generování API klíče
def generate_api_key():
    """Vygeneruje náhodný API klíč"""
    import secrets
    import string

    # Format: sk_test_<32 random characters>
    alphabet = string.ascii_lowercase + string.digits
    random_part = ''.join(secrets.choice(alphabet) for _ in range(32))
    return f"sk_test_{random_part}"


# Test při spuštění
if __name__ == "__main__":
    db = Database('test.db')

    # Vygeneruj testovací klíč
    test_key = generate_api_key()
    print(f"Testovací API klíč: {test_key}")

    db.create_api_key(test_key, "Test User")
    print(f"API klíč vytvořen: {db.verify_api_key(test_key)}")

    # Test batch
    batch_id = db.create_batch(test_key, "Test Batch", "/home/user/documents")
    print(f"Batch vytvořen: {batch_id}")

    # Testovací data
    test_result = {
        'file_name': 'test.pdf',
        'file_hash': 'abc123',
        'file_size': 12345,
        'folder': 'subfolder',
        'relative_path': 'subfolder/test.pdf',
        'processed_at': datetime.now().isoformat(),
        'success': True,
        'results': {
            'pdf_format': {'is_pdf_a3': True, 'exact_version': 'PDF/A-3b'},
            'signatures': [{'valid': True}]
        }
    }

    success, result_id = db.save_result(test_key, test_result, batch_id)
    print(f"Výsledek uložen: {success}, ID: {result_id}")

    # Update batch stats
    db.update_batch_stats(batch_id)

    # Get batches
    batches = db.get_batches()
    print(f"Počet batchů: {len(batches)}")

    # Statistiky
    stats = db.get_statistics(test_key)
    print(f"Statistiky: {stats}")
