# WSGI configuration for PDF DokuCheck PRO v42 with API
# Tento soubor použij v PythonAnywhere WSGI konfiguraci
#
# INSTRUKCE:
# 1. Na PA: git clone z GitHubu, v Web nastav Source code na .../pdf-dokucheck-web/v42
# 2. WSGI configuration file nastav na tento soubor (v42/cieslar_pythonanywhere_com_wsgi.py)
# 3. Save, Reload

import sys
import os

# --- Automatizace deploy: na PC v reload_config.env dejte DEPLOY_TOKEN=pdfcheck_deploy_2025 ---
os.environ.setdefault("DEPLOY_TOKEN", "pdfcheck_deploy_2025")
os.environ.setdefault("PA_USERNAME", "cieslar")
os.environ.setdefault("PA_API_TOKEN", "3dca2714c27e66690e6bb73e96a6b8c64b02abde")
os.environ.setdefault("PA_DOMAIN", "cieslar.pythonanywhere.com")

# Cesta k aplikaci = složka, kde je tento WSGI soubor (složka v42)
path = os.path.dirname(os.path.abspath(__file__))
if path not in sys.path:
    sys.path.insert(0, path)

# Import Flask aplikace
from pdf_dokucheck_pro_v41_with_api import app as application
